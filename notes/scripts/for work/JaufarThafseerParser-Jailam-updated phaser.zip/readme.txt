Just Crt+C the content in word and then Ctr+V the content in the browser

Then we copy the produced table as html, using devtools, and paste that into whatever converter to get an excel or csv