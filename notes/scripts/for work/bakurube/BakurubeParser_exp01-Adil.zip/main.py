import os
import time
from datetime import datetime
import json

def get_num(text=''):
    text = ''.join([c for c in text if c.isnumeric()])
    if len(text)>0:
        return text
    else:
        return 0


start_time = time.time()
start_datetime = datetime.now()

# This is the input json file. Include the folder path if you want(back-slashes need to be escaped like \\).
json_filename = 'quranBakurube.json'
# This is the output text file. Include the folder path if you want(back-slashes need to be escaped like \\).
words_filename = "L_QWords6236.txt"

if os.path.exists(words_filename):
    os.remove(words_filename)

with open(json_filename,'rb') as f:
    data = f.read()
    f.close()

raw = str(data.decode("UTF-8"))
jstr = raw[raw.find('['):] #eliminate part before the first bracket
jstr = jstr.replace('\',\'' , '\'\n,\n\'')
jstr = jstr.replace('\',\"' , '\'\n,\"')
jstr = jstr.replace('\",\'' , '\",\n\'')
jstr = jstr.replace('\'],[' , '\'\n],[')
jstr = jstr.replace('\']]' , '\'\n]]')
lines = jstr.splitlines()

fixed_lines = []
for line in lines:
    if len(line)>0 and line[0]=='\'':
        if line[-1]=='\'':
            line = line.replace('\"','\\\"') #escape the double quotes in text
            line = '\"' + line[1:-1] + '\"'

    line = line.replace('\\\'','\'') #json parser does not recognize escaped '
    fixed_lines.append(line)

jstr = ''.join(fixed_lines)
jstr = jstr.replace('[\"', '[\n        \"')
jstr = jstr.replace('\",\"', '\",\n        \"')
jstr = jstr.replace('\"]', '\"\n    ]')
jstr = jstr.replace('],[', '],\n    [')
jstr = jstr.replace("];", "]")

# with open("latest_raw.txt", "w", encoding="utf-8") as file:
#     file.write(jstr)
#     file.close()

in_list = json.loads(jstr)
# print(len(in_list))

out_list=[]

# for i in range(493):
for i in range(len(in_list)):
    surah_num = int(get_num(in_list[i][0]))
    aaya_num = int(in_list[i][2])
    text_list = in_list[i][5].splitlines()
    # print(text_list)

    the_text = " ".join(text_list)
    the_text = the_text.replace("  ", " ")
    the_text = the_text.replace("  ", " ")
    the_text = the_text.replace("  ", " ").strip()

    # Remove ameen part for end of Al-Fatiha
    if surah_num == 1 and aaya_num == 7:
        text_list = the_text.split()
        text_list = text_list[:-5]
        the_text = " ".join(text_list)
        the_text = the_text.replace("  ", " ").strip()

    # print(the_text)
    # print(str(surah_num) + ":" + str(aaya_num))

    out_list.append(the_text)
    out_list.append('\n')
    out_list.append(str(surah_num) + ":" + str(aaya_num))
    out_list.append('\n')

with open(words_filename, "w", encoding="utf-8") as file:
    file.writelines(out_list)
    file.close()




end_time = time.time()
end_datetime = datetime.now()

print('Start:', start_datetime.strftime("%H:%M:%S"))
print('End:', end_datetime.strftime("%H:%M:%S"))
print('Execution time:', (end_time - start_time), ' seconds')