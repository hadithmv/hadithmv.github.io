const fs = require("fs");

function getData(filePath) {
  return new Promise((resolve, reject) => {
    fs.readFile(filePath, "utf8", (err, data) => {
      if (err) {
        reject(err);
      } else {
        resolve(JSON.parse(data));
      }
    });
  });
}

async function fullJoinRowWise2DFlattenWithEmptyValues(filePath1, filePath2) {
  const arr1 = await getData(filePath1);
  const arr2 = await getData(filePath2);
  const maxLength = Math.max(arr1.length, arr2.length);

  return Array.from({ length: maxLength }, (_, index) =>
    [].concat(
      Array.isArray(arr1[index])
        ? arr1[index]
        : Array(arr2[index].length).fill(""),
      Array.isArray(arr2[index])
        ? arr2[index]
        : Array(arr1[index].length).fill("")
    )
  );
}

const filePath1 = "surah-juz-basmalah-ayah.json";
const filePath2 = "quranBakurube.json";
fullJoinRowWise2DFlattenWithEmptyValues(filePath1, filePath2).then(
  (mergedData) => {
    fs.writeFile(
      "mergedData.json",
      JSON.stringify(mergedData, null, 2),
      (err) => {
        if (err) throw err;
        console.log("Data written to file");
      }
    );
  }
);
