import json

# Sample data
#array1 = [
#    ["A", "B", "", "D"],
#    ["E", "F", "G", "H"],
#]

#array2 = [
#    ["1", "2"],
#    ["3", "4"],
#    ["5", "6"],
#]

# Load data from a JSON file
with open('surah-juz-basmalah-ayah.json', 'r', encoding='utf-8') as f:
    array1 = json.load(f)

with open('quranBakurube.json', 'r', encoding='utf-8') as f:
    array2 = json.load(f)

# Full join the arrays row-wise
merged = []
for i in range(max(len(array1), len(array2))):
    row = []
    if i < len(array1):
        row.extend(array1[i])
    if i < len(array2):
        row.extend(array2[i])
    merged.append(row)

# Write to a JSON file with UTF-8 encoding
with open('mergedData.json', 'w', encoding='utf-8') as f:
    json.dump(merged, f, ensure_ascii=False)

print("Merged data has been written to output.json in UTF-8 format")
