document.addEventListener('paste', (data) => {
    let content = data.clipboardData.getData("text/html")

    let parser = new DOMParser();
    let doc = parser.parseFromString(content, 'text/html');
    let docu = doc.body;
    const paras = docu.querySelectorAll('p');
    let transliterations = [];
    let dv_index = 0;


    paras.forEach((para) => {

        let string = para.innerText

        let sentences = string.split(".");
        sentences.forEach((sentence) => {
            let parts = sentence.split('=');
            if (!! parts[0] )
            transliterations[parts[0]] = parts[1];
        })
    })

    let html = `<table>`;

    ar.forEach((value, i) => {
        html += `<tr>
                    <td>${value}</td>
                    <td>
                        ${dv[i]?.join(' ')}
                    </td>
                </tr>`;
    })

    document.querySelector('#table').innerHTML = html;
})

