document.addEventListener('paste', (data) => {
    let content = data.clipboardData.getData("text/html")

    let parser = new DOMParser();
    let doc = parser.parseFromString(content, 'text/html');
    let docu = doc.body;
    const paras = docu.querySelectorAll('p');
    let dv = [];
    let ar = [];
    let dv_index = 0;

    console.log(paras);

    paras.forEach((para) => {

        let string = para.innerText

        let added_to_dv = false;

        for (let i=0; i < string.length; i++) {
            let code = string.charCodeAt(i);
            if (code > 0x0780 && code < 0x07BF) {
                if (!! dv[dv_index]) {
                    dv[dv_index].push(string);
                } else {
                    dv[dv_index] = [string];
                }
                added_to_dv = true;
                break
            }
        }

        if (! added_to_dv) {
            ar.push(string)
            dv_index++;
        }
    })

    let html = `<table>`;

    ar.forEach((value, i) => {
        html += `<tr>
                    <td>${value}</td>
                    <td>
                        ${dv[i]?.join(' ')}
                    </td>
                </tr>`;
    })

    document.querySelector('#table').innerHTML = html;
})

