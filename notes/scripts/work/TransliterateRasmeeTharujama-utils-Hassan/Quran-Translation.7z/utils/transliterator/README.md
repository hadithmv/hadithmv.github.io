# Transliterator

This utility aids the generation of the alternate (transliterated) translation file
using a custom dictionary swap with a few rules applied.

## Usage

```shell
python ./utils/transliterator/generate_alt_text_with_thikithaana.py
```