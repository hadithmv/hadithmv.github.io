# Utilities

These utility scripts will perform various automated tasks on the translation. Please make sure you don't really change the master_txt translation file.

functions of these utils are as follows

## gen_alternate.py

the script looks into the word_map.csv (tab separated) file for a mapping of arabic->dhivehi words and replaces them in the translation file accordingly to generate the alt_autogen translation file.