select all content from indesign (note that ctrl+a selects only the current section)
cppy paste into word
copy again and paste into the index.html page open in the browser

Then we copy the produced table as html, using devtools, and paste that into whatever converter to get an excel or csv