import re
import json
from bs4 import BeautifulSoup, NavigableString, Tag
import unicodedata # For potential normalization

# --- Configuration ---
HTML_FILE_PATH = 'Book_5.html'
OUTPUT_JSON_PATH = 'tafseer_output.json' # Use new names for testing
OUTPUT_MD_PATH = 'tafseer_output.md'
REMOVE_QURANIC_TEXT = True
DEBUG_FOOTNOTES = False # Can turn back on if needed

# --- Helper Functions ---

def normalize_str(text):
    """Normalize Unicode strings to handle potential variations."""
    if not text:
        return ""
    # NFC normalization combines characters and diacritics
    return unicodedata.normalize('NFC', text)

def clean_text(element):
    """Extracts and cleans text from a BeautifulSoup element, using separator=''."""
    if not element:
        return ""
    # REVERTED: Use separator='' to avoid breaking pattern matching
    text = element.get_text(separator='', strip=True)
    text = normalize_str(text) # Normalize unicode
    # Keep collapsing multiple spaces, but separator='' avoids adding extra ones
    text = re.sub(r'\s+', ' ', text).strip()
    return text

def is_quranic_script(text):
    """Checks if the text is likely Quranic script (not Dhivehi tafseer)."""
    if not text:
        return False

    # 1. Check for Thaana characters (definitive indicator of Dhivehi)
    thaana_pattern = re.compile(r'[\u0780-\u07BF]')
    if thaana_pattern.search(text):
        return False  # Contains Thaana, so it's Tafseer/Dhivehi text

    # 2. Check for pattern like (Number) - should not be skipped
    if re.match(r'^\s*\((\d+)\)', text):
        return False

    # 3. If no Thaana, check if it looks like dedicated Quranic/decorative text
    # Use ranges for standard Arabic, Presentation Forms, specific Quranic marks
    quranic_chars = r'[\u0600-\u06FF\u0750-\u077F\u08A0-\u08FF\uFB50-\uFDFF\uFE70-\uFEFF\u1EE00-\u1EEFF]'
    # Allow ONLY digits, spaces, parens, specific symbols within these lines
    # Exclude general punctuation that might appear in tafseer references
    allowed_in_quranic = r'[()\d\s\uFD3E\uFD3F\ufdfa\ufdfb\ufd3f\ufd3e\u06dd\u06de\ufdfd]'
    quranic_line_pattern = re.compile(f'^({quranic_chars}|{allowed_in_quranic})+$')

    if quranic_line_pattern.match(text):
        # Further checks to increase confidence
        # Check character ratio only if the overall pattern matches
        arabic_count = len(re.findall(quranic_chars, text))
        total_count = len(text)

        # Require a high percentage of Arabic OR presence of specific Quranic markers
        if total_count > 0 and (
            (arabic_count / total_count) > 0.85 # Higher threshold if no Thaana
            or any(sym in text for sym in ['ﭑ','ﭐ','ﭒ','ﭓ','ﱂ','ﱃ','ﱄ','ﱅ', '﷽'])
           ):
            return True # Likely Quranic script line

    # Check specifically for lines that ONLY contain decorative markers/symbols
    specific_marker_pattern = re.compile(r'^[\s\uFD3E\uFD3F\ufdfa\ufdfb\ufd3f\ufd3e\u06dd\u06de\ufdfd]+$')
    if specific_marker_pattern.match(text):
        return True

    return False # Default: Not identified as purely Quranic script

def find_and_replace_footnote_tags(p_element):
    """Finds footnote tags, replaces them with placeholders WITH SPACING,
       and returns the extracted footnote numbers."""
    refs = []
    tags_to_replace = []

    # Find potential footnote links based on href structure
    footnote_links = p_element.find_all('a', href=lambda x: x and 'footnote-' in x)
    tags_to_replace.extend(footnote_links)

    # Find potential footnote spans (adjust class name if needed)
    footnote_spans = p_element.find_all('span', class_='Footnote-reference')
    tags_to_replace.extend(footnote_spans)

    # Sort tags by their position in the document to process them in order
    # Process last first to minimize index shifts during replacement
    tags_to_replace.sort(key=lambda tag: tag.sourceline * 1000 + tag.sourcepos if hasattr(tag, 'sourceline') and tag.sourceline is not None else float('inf'), reverse=True)

    processed_tags = set() # Keep track to avoid processing nested tags twice

    for tag in tags_to_replace:
        # Skip if tag or its parent was already processed
        if tag in processed_tags or (tag.parent and tag.parent in processed_tags):
            continue

        ref_text = clean_text(tag) # Use the standard clean_text
        ref_num_match = re.search(r'(\d+)', ref_text) # Find first sequence of digits
        ref_num = None

        if ref_num_match:
            ref_num = ref_num_match.group(1)
        elif ref_text.isdigit():
            ref_num = ref_text

        if ref_num:
            # ADD SPACES around placeholder for better separation after cleaning
            placeholder = f" __FOOTNOTE_{ref_num}__ "
            try:
                # Replace the tag with the placeholder text node
                tag.replace_with(NavigableString(placeholder))
                if ref_num not in refs:
                    refs.append(ref_num)
                processed_tags.add(tag) # Mark as processed
                 # If the parent span's only purpose was styling the replaced link, mark it too
                if tag.parent and tag.parent.name == 'span' and not clean_text(tag.parent):
                     processed_tags.add(tag.parent)

                # if DEBUG_FOOTNOTES: print(f"      Replaced footnote tag for '{ref_num}' with placeholder.")
            except Exception as e:
                # if DEBUG_FOOTNOTES: print(f"      Error replacing tag for footnote {ref_num}: {e}")
                # If replacement fails, still try to add the ref if found
                if ref_num and ref_num not in refs:
                    refs.append(ref_num)

    # Return refs in the order they likely appeared (reverse the reverse sort)
    return refs[::-1]


# --- Main Parsing Logic ---

try:
    with open(HTML_FILE_PATH, 'r', encoding='utf-8') as f:
        html_content = f.read()
except FileNotFoundError:
    print(f"Error: HTML file not found at {HTML_FILE_PATH}")
    exit()

soup = BeautifulSoup(html_content, 'html.parser')
body = soup.body

if not body:
    print("Error: Could not find the <body> tag in the HTML.")
    exit()

parsed_data = []
footnotes_dict = {}
# --- Footnote dictionary population (keep as is from previous correct version) ---
print("--- Parsing Footnotes ---")
footnote_sections = soup.find_all('section', class_='_idFootnotes')
print(f"Found {len(footnote_sections)} footnote sections.")
for idx, footnote_section in enumerate(footnote_sections):
    footnote_list = footnote_section.find('ol')
    if footnote_list:
        for li in footnote_list.find_all('li', recursive=False):
            a_tag = li.find('a', class_='_idFootnoteAnchor') or li.find('a')
            visible_num_text = clean_text(a_tag) if a_tag else None
            num_key = None
            if visible_num_text and visible_num_text.isdigit(): num_key = visible_num_text
            else:
                 footnote_id = li.get('id')
                 if footnote_id and footnote_id.startswith('footnote-'):
                     match = re.search(r'footnote-(\d+)', footnote_id)
                     if match: num_key = match.group(1)
            if num_key:
                p_tag = li.find('p')
                text = clean_text(p_tag)
                cleaned_footnote_text = re.sub(r'^(\d+|[\u0660-\u0669]+)[\s\.\-–—]*', '', text).strip()
                if num_key in footnotes_dict and footnotes_dict[num_key] != cleaned_footnote_text:
                    if DEBUG_FOOTNOTES: print(f"  Warning: Duplicate footnote key '{num_key}' with different text. Overwriting.")
                elif num_key not in footnotes_dict and DEBUG_FOOTNOTES:
                    print(f"  Stored footnote key: '{num_key}', Text start: '{cleaned_footnote_text[:60]}...'")
                footnotes_dict[num_key] = cleaned_footnote_text
# --- End Footnote Parsing ---
print(f"--- Finished Parsing Footnotes. Total unique footnotes stored: {len(footnotes_dict)}. ---")


# Variables for main loop
current_surah_number = None
current_surah_name = ""
current_aayah_number = ""
current_tafseer_lines = []
current_footnote_refs = [] # Store refs found FOR the current ayah
processing_started = False

# Get all paragraphs... (Keep the logic for finding all_paragraphs)
# ... (finding main_content_elements and all_paragraphs logic - should be ok from previous) ...
main_content_elements = []
for element in body.children:
    if isinstance(element, Tag):
        element_id = element.get('id', '')
        element_classes = element.get('class', [])
        if 'Basic-Graphics-Frame' in element.get('class', []): continue
        is_header_footer_layout = False
        if '_idGenObjectLayout-1' in element_classes:
             inner_divs = element.find_all('div', recursive=False)
             has_graphics = any('Basic-Graphics-Frame' in d.get('class', []) for d in inner_divs)
             if len(inner_divs) > 1:
                 has_page_num = any(p.get('class') == ['no-styles'] and re.match(r'^\s*\d+\s*$', clean_text(p)) for d in inner_divs for p in d.find_all('p', recursive=False))
                 if not has_page_num: has_page_num = any(p.get('class') == ['no-styles'] and re.match(r'^\s*\d+\s*$', clean_text(p)) for d in inner_divs for p in d.find_all('p', recursive=True))
                 has_surah_name_header = any( ('ފޮތް' in clean_text(d) or 'سُوْرَةُ' in clean_text(d)) and len(d.find_all('p')) < 3 for d in inner_divs)
                 if has_graphics or (has_page_num and has_surah_name_header) : is_header_footer_layout = True
        if not is_header_footer_layout: main_content_elements.append(element)

all_paragraphs = []
processed_para_elements = set() # Keep track of elements already processed
for elem in main_content_elements:
     # Prioritize paragraphs directly within the element or its main containers
     candidate_paragraphs = elem.find_all('p', recursive=True) # Find all nested p tags
     for p in candidate_paragraphs:
          # Ensure we haven't already processed this exact element
          if p in processed_para_elements:
               continue
          # Ensure it's not inside a footnote section
          if p.find_parent('section', class_='_idFootnotes'):
               continue
          # Ensure it's not inside something we identified as a header/footer element (might need refinement)
          is_in_header_footer = False
          parent_layout = p.find_parent(class_='_idGenObjectLayout-1')
          if parent_layout and parent_layout not in main_content_elements: # Check if parent was skipped earlier
               is_in_header_footer = True

          if not is_in_header_footer:
              all_paragraphs.append(p)
              processed_para_elements.add(p)

# Map Surah names (key = normalized name ONLY)
surah_map = {
    normalize_str("النِّسَاء"): 4,
}

def store_previous_aayah():
    """Stores the data for the previously processed Aayah block.
       Replaces placeholders with Markdown markers AND SPACING."""
    global current_tafseer_lines, current_footnote_refs, parsed_data
    global current_surah_number, current_surah_name, current_aayah_number

    if current_surah_number is not None and current_aayah_number and current_tafseer_lines:
        tafseer_with_placeholders = "\n".join(current_tafseer_lines).strip()
        tafseer_final_text = tafseer_with_placeholders
        footnotes_data = []

        # Deduplicate refs while preserving order (roughly)
        unique_ordered_refs = []
        seen_refs = set()
        for ref in current_footnote_refs:
             if ref not in seen_refs:
                 unique_ordered_refs.append(ref)
                 seen_refs.add(ref)

        # Sort numerically if possible, otherwise keep order
        try:
            unique_ordered_refs.sort(key=int)
        except ValueError:
            # Keep original extraction order if sorting fails
            pass

        # Replace placeholders with Markdown markers, adding spaces
        for ref_num in unique_ordered_refs:
            placeholder = f"__FOOTNOTE_{ref_num}__"
            markdown_marker = f"[^{ref_num}]"
            # Replace placeholder (with potential spaces around it) with marker (with single spaces around it)
            tafseer_final_text = re.sub(r'\s*' + re.escape(placeholder) + r'\s*', f' {markdown_marker} ', tafseer_final_text)

            footnote_text = footnotes_dict.get(ref_num)
            if footnote_text is None:
                print(f"Warning: Footnote text for reference '{ref_num}' in Aayah {current_aayah_number} not found (storage).")
                footnote_text = f"Footnote {ref_num} text not found"
            footnotes_data.append({ "number": ref_num, "text": footnote_text })

        # Final cleanup of spacing around markers and general text
        tafseer_final_text = re.sub(r'\s{2,}', ' ', tafseer_final_text) # Collapse multiple spaces
        tafseer_final_text = re.sub(r'\s([,.!?;:])', r'\1', tafseer_final_text) # Remove space before punctuation
        tafseer_final_text = re.sub(r'(\()\s', r'\1', tafseer_final_text) # Remove space after opening parenthesis
        tafseer_final_text = re.sub(r'\s(\))', r'\1', tafseer_final_text) # Remove space before closing parenthesis


        parsed_data.append({
            "surah_number": current_surah_number,
            "surah_name": current_surah_name,
            "aayah_number": current_aayah_number,
            "tafseer": tafseer_final_text.strip(),
            "footnotes": footnotes_data
        })

    current_tafseer_lines = []
    current_footnote_refs = []
# --- store_previous_aayah ends ---


print("\n--- Processing Main Content ---")
# --- Main Loop ---
for i, p in enumerate(all_paragraphs):
    # Replace footnote tags with placeholders FIRST
    refs_found = find_and_replace_footnote_tags(p)

    cleaned_p_text = clean_text(p) # Clean text *after* placeholders inserted
    if not cleaned_p_text: continue

    normalized_p_text = normalize_str(cleaned_p_text)
    surah_match = re.match(r'^\s*سُوْرَةُ\s+([\u0600-\u06FF\s]+?)\s*$', normalized_p_text)
    if surah_match:
        store_previous_aayah()
        extracted_surah_name = normalize_str(surah_match.group(1).strip())
        current_surah_name = extracted_surah_name # Use the normalized name found
        current_surah_number = surah_map.get(extracted_surah_name)

        if current_surah_number is None:
            # Check variations if primary fails
            if extracted_surah_name == normalize_str("ال ن ّ ِ سَ ا ء"): current_surah_number = surah_map.get(normalize_str("النِّسَاء"))
            # Add more specific variation checks if needed

        if current_surah_number is None:
            print(f"Warning: Surah number still not found for '{extracted_surah_name}'. Assigning placeholder.")
            current_surah_number = f"Unknown_{extracted_surah_name}"
            processing_started = False # Stop processing if Surah unknown
        else:
            processing_started = True # Start processing if Surah known

        current_aayah_number = ""
        print(f"\n--- Processing Surah {current_surah_number}: {current_surah_name} ---")
        current_footnote_refs.extend(refs_found)
        continue

    if not processing_started: continue

    if REMOVE_QURANIC_TEXT and is_quranic_script(cleaned_p_text):
        if not re.match(r'^\s*\((\d+)\)', cleaned_p_text): continue

    aayah_match = re.match(r'^\s*\((\d+)\)\s*(.*)', cleaned_p_text)
    if aayah_match:
        store_previous_aayah()
        current_aayah_number = aayah_match.group(1)
        initial_tafseer_part = aayah_match.group(2).strip()
        print(f"Found Aayah: {current_aayah_number}")
        current_footnote_refs.extend(refs_found)
        if initial_tafseer_part:
             if not (REMOVE_QURANIC_TEXT and is_quranic_script(initial_tafseer_part)):
                  current_tafseer_lines.append(initial_tafseer_part)
        continue

    if current_aayah_number:
        if not re.fullmatch(r'\s*\d+\s*', cleaned_p_text):
             current_tafseer_lines.append(cleaned_p_text)
             current_footnote_refs.extend(refs_found)

# Store the very last Aayah block
store_previous_aayah()

# --- Output Generation ---
# (Output generation logic remains the same)
# JSON Output
try:
    with open(OUTPUT_JSON_PATH, 'w', encoding='utf-8') as f:
        json.dump(parsed_data, f, ensure_ascii=False, indent=4)
    print(f"\nSuccessfully created JSON file: {OUTPUT_JSON_PATH}")
except Exception as e: print(f"Error writing JSON file: {e}")

# Markdown Output
md_output = ""
last_surah = None
for item in parsed_data:
    if item["surah_number"] != last_surah:
        md_output += f"# Surah {item['surah_number']}: {item['surah_name']}\n\n"
        last_surah = item["surah_number"]
    md_output += f"## Aayah {item['aayah_number']}\n\n"
    md_output += f"{item['tafseer']}\n\n"
    if item['footnotes']:
        md_output += "---\n**Footnotes:**\n\n"
        sorted_footnotes = sorted(item['footnotes'], key=lambda x: int(x['number']))
        for fn in sorted_footnotes: md_output += f"[^{fn['number']}]: {fn['text']}\n"
        md_output += "\n---\n\n"
    else: md_output += "\n"

try:
    with open(OUTPUT_MD_PATH, 'w', encoding='utf-8') as f: f.write(md_output)
    print(f"Successfully created Markdown file: {OUTPUT_MD_PATH}")
except Exception as e: print(f"Error writing Markdown file: {e}")

print("\nProcessing complete.")