import re
import json
from bs4 import BeautifulSoup, NavigableString, Tag
import unicodedata

# --- Configuration ---
HTML_FILE_PATH = 'Book_5.html' # Use the updated HTML file path
OUTPUT_JSON_PATH = 'tafseer_output_renumbered.json'
OUTPUT_MD_PATH = 'tafseer_output_renumbered.md'
REMOVE_QURANIC_TEXT = True
DEBUG_FOOTNOTES = False # Set True to debug footnote issues

# --- Helper Functions ---
# (Keep normalize_str, clean_text, is_quranic_script functions as they were)
def normalize_str(text):
    if not text: return ""
    return unicodedata.normalize('NFC', text)

def clean_text(element):
    if not element: return ""
    text = element.get_text(separator='', strip=True) # Using separator=''
    text = normalize_str(text)
    text = re.sub(r'\s+', ' ', text).strip()
    return text

def is_quranic_script(text):
    if not text: return False
    thaana_pattern = re.compile(r'[\u0780-\u07BF]')
    if thaana_pattern.search(text): return False
    if re.match(r'^\s*\((\d+)\)', text): return False
    quranic_chars=r'[\u0600-\u06FF\u0750-\u077F\u08A0-\u08FF\uFB50-\uFDFF\uFE70-\uFEFF\u1EE00-\u1EEFF]'
    allowed_in_quranic=r'[()\d\s\uFD3E\uFD3F\ufdfa\ufdfb\ufd3f\ufd3e\u06dd\u06de\ufdfd]'
    quranic_line_pattern=re.compile(f'^({quranic_chars}|{allowed_in_quranic})+$')
    if quranic_line_pattern.match(text):
        arabic_count = len(re.findall(quranic_chars, text))
        total_count = len(text)
        if total_count > 0 and ((arabic_count / total_count) > 0.85 or any(sym in text for sym in ['ﭑ','ﭐ','ﭒ','ﭓ','ﱂ','ﱃ','ﱄ','ﱅ', '﷽'])):
            if len(text) < 15 and not any(sym in text for sym in ['ﭑ','ﭐ','ﭒ','ﭓ','ﱂ','ﱃ','ﱄ','ﱅ', '﷽']): return False
            return True
    specific_marker_pattern=re.compile(r'^[\s\uFD3E\uFD3F\ufdfa\ufdfb\ufd3f\ufd3e\u06dd\u06de\ufdfd]+$')
    if specific_marker_pattern.match(text): return True
    return False

def find_and_replace_footnote_tags_by_id(p_element):
    """Finds footnote <a> tags based on href, replaces them with ID-based placeholders,
       and returns the extracted footnote ID numbers."""
    refs_id_nums = []
    tags_to_replace = []
    footnote_links = p_element.find_all('a', href=lambda x: x and '#footnote-' in x)
    tags_to_replace.extend(footnote_links)
    footnote_links_with_id = p_element.find_all('a', id=lambda x: x and x.startswith('footnote-') and x.endswith('-backlink'))
    for tag in footnote_links_with_id:
         if tag not in tags_to_replace: tags_to_replace.append(tag)
    tags_to_replace.sort(key=lambda tag: tag.sourceline * 1000 + tag.sourcepos if hasattr(tag, 'sourceline') and tag.sourceline is not None else float('inf'), reverse=True)
    processed_tags = set()
    for tag in tags_to_replace:
        if tag in processed_tags or (tag.parent and tag.parent in processed_tags): continue
        href = tag.get('href', '')
        link_id_attr = tag.get('id', '')
        id_match = re.search(r'#footnote-(\d+)', href)
        id_num = id_match.group(1) if id_match else None
        if not id_num:
             id_match_from_link_id = re.search(r'footnote-(\d+)-backlink', link_id_attr)
             if id_match_from_link_id: id_num = id_match_from_link_id.group(1)
        if id_num:
            placeholder = f" __FOOTNOTE_ID_{id_num}__ " # Placeholder uses the ID
            try:
                tag.replace_with(NavigableString(placeholder))
                if id_num not in refs_id_nums: refs_id_nums.append(id_num)
                processed_tags.add(tag)
                if tag.parent and tag.parent.name == 'span' and not clean_text(tag.parent): processed_tags.add(tag.parent)
                # if DEBUG_FOOTNOTES: print(f"      Replaced tag pointing to/having ID '{id_num}' with placeholder.")
            except Exception as e:
                # if DEBUG_FOOTNOTES: print(f"      Error replacing tag for footnote ID {id_num}: {e}")
                if id_num and id_num not in refs_id_nums: refs_id_nums.append(id_num)
    return refs_id_nums[::-1]

# --- Main Parsing Logic ---
try:
    with open(HTML_FILE_PATH, 'r', encoding='utf-8') as f: html_content = f.read()
except FileNotFoundError: print(f"Error: HTML file not found at {HTML_FILE_PATH}"); exit()
soup = BeautifulSoup(html_content, 'html.parser')
body = soup.body
if not body: print("Error: Could not find the <body> tag."); exit()

parsed_data = []
# --- Footnote dictionary population (key=ID, value=dict) ---
footnotes_map = {} # Key: ID_Num, Value: {'visible_num': str, 'text': str}
print("--- Parsing Footnotes ---")
footnote_sections = soup.find_all('section')
processed_footnote_sections = 0
for section in footnote_sections:
    footnote_list = section.find('ol')
    if footnote_list and footnote_list.find('li', id=lambda x: x and x.startswith('footnote-')):
        processed_footnote_sections += 1
        for li in footnote_list.find_all('li', id=lambda x: x and x.startswith('footnote-')):
            li_id = li.get('id')
            id_num_match = re.search(r'footnote-(\d+)', li_id)
            id_num = id_num_match.group(1) if id_num_match else None
            visible_num = "-"
            a_tag = li.find('a', href=lambda x: x and f'#footnote-{id_num}-backlink' in x if id_num else False) or li.find('a')
            if a_tag:
                visible_num_text = clean_text(a_tag)
                if re.match(r'^-?\d+$', visible_num_text): visible_num = visible_num_text
            p_tag = li.find('p')
            text = clean_text(p_tag) if p_tag else clean_text(li)
            cleaned_footnote_text = re.sub(r'^([\d-]+|[\u0660-\u0669]+)[\s\.\-–—]*', '', text).strip()
            if id_num:
                if id_num in footnotes_map and footnotes_map[id_num]['text'] != cleaned_footnote_text:
                     if DEBUG_FOOTNOTES: print(f"  Warning: Duplicate footnote ID '{id_num}' with DIFFERENT text. Overwriting.")
                footnotes_map[id_num] = {'visible_num': visible_num, 'text': cleaned_footnote_text}
print(f"--- Finished Parsing Footnotes. Total unique IDs stored: {len(footnotes_map)}. ---")
# --- End Footnote Parsing ---

# Variables for main loop
current_surah_number = None
current_surah_name = ""
current_aayah_number = ""
current_tafseer_lines = []
current_footnote_id_refs = [] # Store ID numbers found FOR the current ayah
processing_started = False

# --- Find all relevant paragraphs (keep robust logic) ---
# ... (finding all_paragraphs logic) ...
main_content_elements = []
for element in body.children:
    if isinstance(element, Tag):
        element_classes = element.get('class', [])
        if 'Basic-Graphics-Frame' in element_classes: continue
        is_header_footer_layout = False
        if '_idGenObjectLayout-1' in element_classes:
             inner_divs = element.find_all('div', recursive=False)
             has_graphics = any('Basic-Graphics-Frame' in d.get('class', []) for d in inner_divs)
             if len(inner_divs) > 1:
                 has_page_num = any(p.get('class') == ['no-styles'] and re.match(r'^\s*\d+\s*$', clean_text(p)) for d in inner_divs for p in d.find_all('p', recursive=False))
                 if not has_page_num: has_page_num = any(p.get('class') == ['no-styles'] and re.match(r'^\s*\d+\s*$', clean_text(p)) for d in inner_divs for p in d.find_all('p', recursive=True))
                 has_surah_name_header = any( ('ފޮތް' in clean_text(d) or 'سُوْرَةُ' in clean_text(d)) and len(d.find_all('p')) < 3 for d in inner_divs)
                 if has_graphics or (has_page_num and has_surah_name_header) : is_header_footer_layout = True
        if not is_header_footer_layout: main_content_elements.append(element)

all_paragraphs = []
processed_para_elements = set()
for elem in main_content_elements:
     candidate_paragraphs = elem.find_all('p', recursive=True)
     for p in candidate_paragraphs:
          if p in processed_para_elements: continue
          if p.find_parent('section', class_='_idFootnotes'): continue # Skip notes section explicitly
          # Add check for parent being a footnote section (new structure)
          parent_section = p.find_parent('section')
          if parent_section and parent_section.find('ol') and parent_section.find('li', id=lambda x: x and x.startswith('footnote-')):
               continue

          is_in_header_footer = False
          parent_layout = p.find_parent(class_='_idGenObjectLayout-1')
          if parent_layout and parent_layout not in main_content_elements: is_in_header_footer = True

          if not is_in_header_footer:
              all_paragraphs.append(p)
              processed_para_elements.add(p)
# --- End finding paragraphs ---

# Map Surah names (key = normalized name ONLY)
surah_map = {
    normalize_str("النِّسَاء"): 4,
}

# --- MODIFIED: store_previous_aayah to handle renumbering ---
def store_previous_aayah():
    """Stores the data for the previously processed Aayah block.
       Renumber footnotes sequentially starting from 1 for this Aayah."""
    global current_tafseer_lines, current_footnote_id_refs, parsed_data
    global current_surah_number, current_surah_name, current_aayah_number

    if current_surah_number is not None and current_aayah_number and current_tafseer_lines:
        tafseer_with_placeholders = "\n".join(current_tafseer_lines).strip()
        tafseer_final_text = tafseer_with_placeholders
        footnotes_data = []

        # 1. Get unique footnote IDs referenced in this Aayah, preserving order
        unique_id_refs_ordered = list(dict.fromkeys(current_footnote_id_refs))

        # 2. Create the mapping from original ID to new sequential number (for this Aayah)
        ayah_display_map = {id_num: str(idx + 1) for idx, id_num in enumerate(unique_id_refs_ordered)}

        if DEBUG_FOOTNOTES and unique_id_refs_ordered:
            print(f"    Finalizing Aayah {current_aayah_number}. Unique ID Refs (ordered): {unique_id_refs_ordered}")
            print(f"    Aayah Display Map: {ayah_display_map}")

        # 3. Replace placeholders using the new sequential numbers
        for id_num in unique_id_refs_ordered:
            placeholder = f"__FOOTNOTE_ID_{id_num}__"
            new_display_num = ayah_display_map.get(id_num)
            if new_display_num:
                markdown_marker = f"[^{new_display_num}]" # Marker uses NEW sequential number
                tafseer_final_text = re.sub(r'\s*' + re.escape(placeholder) + r'\s*', f' {markdown_marker} ', tafseer_final_text)
                if DEBUG_FOOTNOTES: print(f"    Replacing '{placeholder}' with '{markdown_marker}'")
            else:
                # Should not happen if logic is correct, but handle defensively
                print(f"    Warning: Could not find new display number for ID '{id_num}' in Aayah {current_aayah_number}. Placeholder left.")


        # 4. Prepare final footnote data list using NEW sequential numbers
        for id_num in unique_id_refs_ordered:
            footnote_info = footnotes_map.get(id_num)
            new_display_num = ayah_display_map.get(id_num)

            if footnote_info and new_display_num:
                footnotes_data.append({
                    "number": new_display_num, # Use the NEW sequential number
                    "text": footnote_info['text']
                })
            else:
                # If original footnote text wasn't found OR mapping failed
                display_num_for_warning = new_display_num if new_display_num else f"ID-{id_num}?"
                print(f"Warning: Footnote text/mapping failed for ID '{id_num}' (display num {display_num_for_warning}) in Aayah {current_aayah_number}.")
                # Add placeholder entry to maintain structure
                footnotes_data.append({
                    "number": display_num_for_warning,
                    "text": f"Footnote text for ID {id_num} not found"
                })

        # Final cleanup of spacing
        tafseer_final_text = re.sub(r'\s{2,}', ' ', tafseer_final_text).strip()
        tafseer_final_text = re.sub(r'\s([,.!?;:])', r'\1', tafseer_final_text)
        tafseer_final_text = re.sub(r'(\()\s', r'\1', tafseer_final_text)
        tafseer_final_text = re.sub(r'\s(\))', r'\1', tafseer_final_text)

        # Sort footnotes by the NEW sequential number before storing
        footnotes_data.sort(key=lambda x: int(x['number']) if x['number'].isdigit() else float('inf'))

        parsed_data.append({
            "surah_number": current_surah_number,
            "surah_name": current_surah_name,
            "aayah_number": current_aayah_number,
            "tafseer": tafseer_final_text.strip(),
            "footnotes": footnotes_data # Contains NEW sequential numbers
        })

    current_tafseer_lines = []
    current_footnote_id_refs = [] # Reset IDs
# --- store_previous_aayah ends ---


print("\n--- Processing Main Content ---")
# --- Main Loop (Processing Paragraphs) ---
# ... (Loop remains the same as previous version, it collects ID refs) ...
for i, p in enumerate(all_paragraphs):
    refs_id_nums_found = find_and_replace_footnote_tags_by_id(p) # Replace tags with ID placeholders
    cleaned_p_text = clean_text(p) # Clean text *with* ID placeholders
    if not cleaned_p_text: continue
    normalized_p_text = normalize_str(cleaned_p_text)
    surah_match = re.match(r'^\s*سُوْرَةُ\s+([\u0600-\u06FF]+)\s*$', normalized_p_text)
    if surah_match:
        store_previous_aayah()
        extracted_surah_name = normalize_str(surah_match.group(1).strip())
        current_surah_name = extracted_surah_name
        current_surah_number = surah_map.get(extracted_surah_name)
        if current_surah_number is None: # Add fallbacks if needed
             pass
        if current_surah_number is None:
            print(f"Warning: Surah number not found for '{extracted_surah_name}'. Skipping related content.")
            processing_started = False
        else:
            processing_started = True
            print(f"\n--- Processing Surah {current_surah_number}: {current_surah_name} ---")
        current_aayah_number = ""
        current_footnote_id_refs.extend(refs_id_nums_found) # Store IDs found
        continue
    if not processing_started: continue
    aayah_match = re.match(r'^\s*\((\d+)\)\s*(.*)', cleaned_p_text)
    if aayah_match:
        store_previous_aayah()
        current_aayah_number = aayah_match.group(1)
        initial_tafseer_part = aayah_match.group(2).strip()
        print(f"Found Aayah: {current_aayah_number}")
        current_footnote_id_refs.extend(refs_id_nums_found) # Store IDs found in this line
        if initial_tafseer_part:
             if not (REMOVE_QURANIC_TEXT and is_quranic_script(initial_tafseer_part)):
                  current_tafseer_lines.append(initial_tafseer_part)
        continue
    if REMOVE_QURANIC_TEXT and is_quranic_script(cleaned_p_text): continue
    if current_aayah_number:
        if cleaned_p_text and not cleaned_p_text.isspace():
             if not re.fullmatch(r'(\s*__FOOTNOTE_ID_\d+__\s*)+', cleaned_p_text):
                 current_tafseer_lines.append(cleaned_p_text)
        current_footnote_id_refs.extend(refs_id_nums_found) # Store IDs found in this line

# Store the very last Aayah block
store_previous_aayah()

# --- Output Generation ---
# (Output generation logic remains the same, uses 'number' field which is now the renumbered sequential number)
# JSON Output
try:
    with open(OUTPUT_JSON_PATH, 'w', encoding='utf-8') as f:
        json.dump(parsed_data, f, ensure_ascii=False, indent=4)
    print(f"\nSuccessfully created JSON file: {OUTPUT_JSON_PATH}")
except Exception as e: print(f"Error writing JSON file: {e}")
# Markdown Output
md_output = ""
last_surah = None
for item in parsed_data:
    if item["surah_number"] != last_surah:
        md_output += f"# Surah {item['surah_number']}: {item['surah_name']}\n\n"
        last_surah = item["surah_number"]
    md_output += f"## Aayah {item['aayah_number']}\n\n"
    md_output += f"{item['tafseer']}\n\n" # Contains [^1], [^2] markers now
    if item['footnotes']:
        md_output += "---\n**Footnotes:**\n\n"
        # Footnotes are already sorted by the new sequential number in store_previous_aayah
        for fn in item['footnotes']:
            md_output += f"[^{fn['number']}]: {fn['text']}\n" # Definition uses NEW sequential number
        md_output += "\n---\n\n"
    else: md_output += "\n"
try:
    with open(OUTPUT_MD_PATH, 'w', encoding='utf-8') as f: f.write(md_output)
    print(f"Successfully created Markdown file: {OUTPUT_MD_PATH}")
except Exception as e: print(f"Error writing Markdown file: {e}")

print("\nProcessing complete.")