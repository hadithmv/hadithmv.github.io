import requests
from bs4 import BeautifulSoup
import json
import time
import argparse
from tqdm import tqdm

def scrape_page(url_number):
    """
    Scrape data from a specific page on gaanoon.com
    """
    url = f"https://gaanoon.com/dictionary/word/{url_number}"
    try:
        # Add a user agent to avoid being blocked
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
        }
        
        response = requests.get(url, headers=headers)
        response.raise_for_status()
        
        # Parse the HTML content
        soup = BeautifulSoup(response.text, 'html.parser')
        
        # Extract the data from column 1 (h1 tag)
        h1_tag = soup.select_one('section#article h1')
        column1 = h1_tag.text.strip() if h1_tag else "Not found"
        
        # Extract the data from column 2 (div.editor-content text)
        # Key fix: Look for the direct text content of the div.editor-content element
        editor_content_div = soup.select_one('div.editor-content')
        if editor_content_div:
            # Get all text directly from the div (not just from p tags)
            column2 = editor_content_div.get_text(strip=True)
        else:
            column2 = "Not found"
        
        # Return the extracted data along with the URL number
        return {
            "id": url_number,
            "column1": column1,
            "column2": column2
        }
        
    except requests.exceptions.RequestException as e:
        print(f"Error fetching URL {url}: {e}")
        return {
            "id": url_number,
            "column1": "Error",
            "column2": f"Failed to fetch: {str(e)}"
        }

def main():
    # Set up command line arguments
    parser = argparse.ArgumentParser(description='Scrape data from gaanoon.com')
    parser.add_argument('start', type=int, help='Starting ID number')
    parser.add_argument('end', type=int, help='Ending ID number')
    parser.add_argument('--output', type=str, default='gaanoon_data.json', help='Output JSON file name')
    parser.add_argument('--delay', type=float, default=1.0, help='Delay between requests in seconds')
    
    args = parser.parse_args()
    
    # Validate input
    if args.start > args.end:
        print("Error: Start number must be less than or equal to end number.")
        return
    
    # Initialize results list
    results = []
    
    # Create a progress bar
    print(f"Scraping data from gaanoon.com for IDs {args.start} to {args.end}...")
    for i in tqdm(range(args.start, args.end + 1)):
        # Scrape the page
        data = scrape_page(i)
        results.append(data)
        
        # Add delay to avoid overwhelming the server
        if i < args.end:
            time.sleep(args.delay)
    
    # Save the data as JSON
    with open(args.output, 'w', encoding='utf-8') as f:
        json.dump(results, f, ensure_ascii=False, indent=2)
    
    print(f"Scraping complete. Data saved to {args.output}")
    print(f"Total entries scraped: {len(results)}")
    
    # Report on missing data
    missing_column2 = sum(1 for item in results if item["column2"] == "Not found")
    if missing_column2 > 0:
        print(f"Warning: {missing_column2} entries have missing column2 data.")

if __name__ == "__main__":
    main()