from urllib import request
import json
import time
from datetime import datetime
import os

def get_num(text=''):
    text = ''.join([c for c in text if c.isnumeric()])
    if len(text)>0:
        return text
    else:
        return 0

def clean_js(data):
    raw = str(data.decode("UTF-8"))
    jstr = raw[raw.find('['):]  # eliminate part before the first bracket
    jstr = jstr.replace('\',\'', '\'\n,\n\'')
    jstr = jstr.replace('\',\"', '\'\n,\"')
    jstr = jstr.replace('\",\'', '\",\n\'')
    jstr = jstr.replace('\'],[', '\'\n],[')
    jstr = jstr.replace('\']]', '\'\n]]')
    lines = jstr.splitlines()

    fixed_lines = []
    for line in lines:
        if len(line) > 0 and line[0] == '\'':
            if line[-1] == '\'':
                line = line.replace('\"', '\\\"')  # escape the double quotes in text
                line = '\"' + line[1:-1] + '\"'

        line = line.replace('\\\'', '\'')  # json parser does not recognize escaped '
        fixed_lines.append(line)

    jstr = ''.join(fixed_lines)
    jstr = jstr.replace('[\"', '[\n        \"')
    jstr = jstr.replace('\",\"', '\",\n        \"')
    jstr = jstr.replace('\"]', '\"\n    ]')
    jstr = jstr.replace('],[', '],\n    [')
    jstr = jstr.replace("];", "]")
    list_x = json.loads(jstr)
    return list_x

def is_balanced(text=""):
    pair = {'(': ')', '[': ']', '{': '}', '"': '"', '=': '=', '“': '“'}
    brackets = ['(', ')', '[', ']', '{', '}', '"', '=', '“']
    stack = []
    for c in text:
        if c in brackets:
            if len(stack) > 0:
                if pair[stack[-1]] == c:
                    stack.pop()
                elif c in pair:
                    stack.append(c)
            else: #if (len(stack) == 0)
                if c in pair:
                    stack.append(c)
                else: #if not an opening bracket
                    return False, [c]
    unbalance=len(stack)
    res = (len(stack)==0)
    if unbalance !=0:
        pass
    return res, stack

# url = 'https://raw.githubusercontent.com/hadithmv/hadithmv.github.io/master/js/json/quranBakurube.js'
# url = "https://raw.githubusercontent.com/hadithmv/hadithmv.github.io/master/js/json/raw/quranBakurube.json"
url = "https://raw.githubusercontent.com/hadithmv/hadithmv.github.io/refs/heads/master/js/json/quranBakurube.json"

header_filename = 'surah-juz-basmalah-ayah.js'
json_filename = 'quranBakurube.json'

out_fname = "ijmaly_bracket_errors04a.txt"

if os.path.exists(out_fname):os.remove(out_fname)
if os.path.exists(json_filename):
    os.remove(json_filename)


start_time = time.time()
start_datetime = datetime.now()

response = request.urlretrieve(url, json_filename)
print(response)
print('downloaded:\t' + response[0])

with open(header_filename,'rb') as f:
    dataA = f.read()
    f.close()

listA = clean_js(dataA)

with open(json_filename,'rb') as f:
    dataB = f.read()
    f.close()

listB = clean_js(dataB)

# in_list = json.loads(raw)
in_list = [[listA[i][j] for j in range(len(listA[i]))]+[listB[i][k] for k in range(len(listB[i]))] for i in range(len(listA))]
# print(len(in_list))

ijmaly_list=[]

# for i in range(493):
for i in range(len(in_list)):
    surah_num = int(get_num(in_list[i][0]))
    aaya_num = int(in_list[i][2])

    # This is only for breakpoints
    if surah_num==2 and aaya_num==93:
        surah_num = surah_num
        pass

    is_balanced_res, remaining_stack = is_balanced(in_list[i][6])
    # if not is_balanced(in_list[i][6]):
    if not is_balanced_res:
        if remaining_stack==[]:
            remaining_stack=['unknown']
        this_ijmaly= [in_list[i][6], str(surah_num) + ":" + str(aaya_num), "unbalanced:"+''.join(remaining_stack)]
        ijmaly_list.append(this_ijmaly)

with open(out_fname, 'w', encoding='utf-8') as file:
    json.dump(ijmaly_list, file, ensure_ascii=False, indent=4)
    file.close()

end_time = time.time()
end_datetime = datetime.now()

print('Ijmaly Bracket errors:\t' + str(len(ijmaly_list)))
print('Start:', start_datetime.strftime("%H:%M:%S"))
print('End:', end_datetime.strftime("%H:%M:%S"))
print('Execution time:', (end_time - start_time), ' seconds')